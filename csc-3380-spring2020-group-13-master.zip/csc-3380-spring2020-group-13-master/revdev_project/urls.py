"""revdev_project URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import TokenRefreshView

from revdev_user.views import ObtainSocialAuthToken, UserProfileView, LoginPage, UserFriends
from socket_communication.views import ListGroup, MessageView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('queue/', include('queue_playlist.urls')),
    path('login_tests/', include('revdev_user.urls')),
    path('messaging_tests/', include('socket_communication.urls')),
    path('api/token/', ObtainSocialAuthToken.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),

    path('api/me/', UserProfileView.as_view(), name='me_profile_view'),
    path('api/me/friends/', UserFriends.as_view(), name='me_friends_view'),

    path('api/user/<int:pk>/', UserProfileView.as_view(), name='profile_view_2'),

    path('api/group/', ListGroup.as_view(), name='list_groups'),

    path('api/messages/', MessageView.as_view(), name='message_view'),
    path('api/messages/<int:group_id>/', MessageView.as_view(), name='list_group_messages'),

    path('login', LoginPage.as_view(), name='login_page')
]
