from channels.db import database_sync_to_async



# This decorator turns this function from a synchronous function into an async one
# we can call from our async consumers, that handles Django DBs correctly.
# For more, see http://channels.readthedocs.io/en/latest/topics/databases.html
from socket_communication.exceptions import ClientError
from socket_communication.models import Group

@database_sync_to_async
def get_group_or_error(group_id, user):
    """
    Tries to fetch a room for the user, checking permissions along the way.
    """
    # Check if the user is logged in
    if not user.is_authenticated:
        raise ClientError("USER_HAS_TO_LOGIN")
    # Find the room they requested (by ID)
    try:
        group = Group.objects.get(pk=group_id)
    except group.DoesNotExist:
        raise ClientError("ROOM_INVALID")

    # check if member is actually part of group.
    if group.group_owner != user and user not in group.group_members.all():
        raise ClientError("Not PART OF GROUP")

    return group
