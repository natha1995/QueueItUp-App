from urllib.parse import parse_qs

from channels.auth import AuthMiddlewareStack
from channels.db import database_sync_to_async
from django.contrib.auth.models import AnonymousUser
from django.db import close_old_connections
from rest_framework_simplejwt import authentication, exceptions
from rest_framework_simplejwt.tokens import Token

from revdev_user.utils import get_account_adapter


@database_sync_to_async
def get_user(scope):
    raw_token = parse_qs(scope["query_string"].decode("utf8"))["token"][0]
    jwt_helper = authentication.JWTAuthentication()
    clean_token = jwt_helper.get_validated_token(raw_token)
    user = jwt_helper.get_user(clean_token)
    path = get_account_adapter(user).get_avatar_path()
    return user, path

class TokenAuthMiddleware:

    def __init__(self, inner):
        self.inner = inner

    def __call__(self, scope):
        return TokenAuthMiddlewareInstance(scope, self)

class TokenAuthMiddlewareInstance:
    """
    Yeah, this is black magic:
    https://github.com/django/channels/issues/1399
    """
    def __init__(self, scope, middleware):
        self.middleware = middleware
        self.scope = dict(scope)
        self.inner = self.middleware.inner

    async def __call__(self, receive, send):
        try:
            user, path = await get_user(self.scope)
            self.scope['user'] = user
            self.scope['user-path'] = path
        except (exceptions.AuthenticationFailed, exceptions.InvalidToken, exceptions.TokenError) as e:
            self.scope['user'] = AnonymousUser()
        inner = self.inner(self.scope)
        return await inner(receive, send)

TokenAuthMiddlewareStack = lambda inner: TokenAuthMiddleware(AuthMiddlewareStack(inner))