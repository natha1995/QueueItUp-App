from django.db.models import Q
from django.shortcuts import render
from django.views.generic import ListView

from rest_framework import generics, status
from rest_framework.renderers import TemplateHTMLRenderer
from rest_framework.response import Response
from rest_framework.views import APIView

from socket_communication.models import Group, Message
from socket_communication.serializers import GroupSerializer, MessageSerializer


class ListGroup(APIView):
    serializer_class = GroupSerializer

    def get(self, request):
        queryset = Group.objects.filter(Q(group_owner=self.request.user) | Q(group_members__id__contains=self.request.user.id)).distinct()
        serializer = self.serializer_class(queryset, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = self.serializer_class(request.user.profile, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class MessageView(APIView):
    serializer_class = MessageSerializer

    def get(self, request, group_id, pk=None):
        messages = Message.objects.filter(group_id=group_id).order_by('-timestamp')[:10]
        messages = reversed(messages)

        if messages is None:
            return Response(status=status.HTTP_400_BAD_REQUEST)

        serializer = self.serializer_class(messages, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        serializer = self.serializer_class(data=request.data, context={"request":request})
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        print(serializer.errors)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)