from django.urls import path

from . import views

urlpatterns = [
    path('', views.ListGroup.as_view(), name='index'),
]