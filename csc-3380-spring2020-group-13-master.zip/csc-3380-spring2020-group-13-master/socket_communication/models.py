from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer
from django.db import models
from django.contrib.auth.models import User

from revdev_user.utils import get_account_adapter


class Group(models.Model):
    group_owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="group_owner")
    group_name = models.CharField(max_length=30)
    group_members = models.ManyToManyField(User, related_name="group_members")


class Message(models.Model):
    body = models.TextField(max_length=200)
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name="sender")
    timestamp = models.DateTimeField('timestamp', auto_now_add=True)
    group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name="group")

    def notify_ws_clients(self):
        """
        Inform client there is a new message.
        """

        message = {
            "type": "chat.message",
            "group_id": self.group.id,
            "username": self.sender.username,
            "message": self.body,
            "avatar": get_account_adapter(self.sender).get_avatar_path()
        }

        channel_layer = get_channel_layer()
        async_to_sync(channel_layer.group_send)(self.group.group_name.replace(' ', '-'), message)

    def save(self, *args, **kwargs):
        """
        Trims white spaces, saves the message and notifies the recipient via WS
        if the message is new.
        """
        new = self.id
        self.body = self.body.strip()
        super(Message, self).save(*args, **kwargs)
        if new is None:
            self.notify_ws_clients()