from django.apps import AppConfig


class SocketCommunicationConfig(AppConfig):
    name = 'socket_communication'
