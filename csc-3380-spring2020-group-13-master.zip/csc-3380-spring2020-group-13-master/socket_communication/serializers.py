from urllib.error import HTTPError

from django.contrib.auth import get_user_model
from rest_framework import serializers
from revdev_user.serializers import RevDevUserSerializer
from socket_communication.models import Group, Message

UserModel = get_user_model()


class GroupSerializer(serializers.ModelSerializer):
    group_members = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Group
        depth = 1
        fields = ['id', 'group_name', 'group_members']

    def get_group_members(self, object):
        memberSerializer = RevDevUserSerializer([user.profile for user in object.group_members.all()], many=True)
        return memberSerializer.data


class MessageSerializer(serializers.ModelSerializer):
    sender = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Message
        fields = ['id', 'body', 'group', 'sender']
        extra_kwargs = {'sender': {'required': False}}

    def validate(self, attrs):
        if 'sender' not in attrs:
            attrs["sender"] = self.context['request'].user
        return super(MessageSerializer, self).validate(attrs)

    def get_sender(self, object):
        memberSerializer = RevDevUserSerializer(object.sender.profile, many=False)
        return memberSerializer.data