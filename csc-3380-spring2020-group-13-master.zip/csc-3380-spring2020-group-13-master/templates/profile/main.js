function edit_row(no) {
    document.getElementById("edit_button" + no).style.display = "none";
    document.getElementById("save_button" + no).style.display = "block";

    var name = document.getElementById("name_row" + no);

    var name_data = name.innerHTML;

    name.innerHTML = "<input type='text' id='name_text" + no + "' value='" + name_data + "'>";
}

function save_row(no) {
    var name_val = document.getElementById("name_text" + no).value;
    editBio(name_val).then(res => {
        document.getElementById("name_row" + no).innerHTML = name_val;

        document.getElementById("edit_button" + no).style.display = "block";
        document.getElementById("save_button" + no).style.display = "none";
    })
}


// change the user's avatar, bio, and name on page load.
getUserMe().then(res => {
    const avatar_url = res.avatar_url
    const first_name = res.user.first_name
    const last_name = res.user.last_name
    const bio = res.bio
    $("#avatar").attr('src', avatar_url)
    $("#revdev_name").text(`${first_name + ' ' + last_name}`)
    $("#name_row1").text(bio)
})

getUserMeFriends().then(friends => {

    let friends_container = $("#friends_container")
    friends_container.empty()

    for (let profile of friends) {
        const first_name = profile.user.first_name
        const last_name = profile.user.last_name
        let friends_template = `<a href="#">${first_name + ' ' + last_name}</a>`;
        friends_container.append(friends_template)
    }
})