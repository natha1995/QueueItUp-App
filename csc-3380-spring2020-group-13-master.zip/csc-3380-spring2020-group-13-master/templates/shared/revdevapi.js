
function getUserMe() {
    return apiFetch('api/me/', 'GET')
}

function editBio(bio_info) {
    return apiFetch('api/me/', 'POST', {
        "bio": bio_info
    })
}

function getUserMeFriends() {
    return apiFetch('api/me/friends/', 'GET')
}