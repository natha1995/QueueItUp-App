// we override the fetch API
(function () {
    var originalFetch = fetch;
    fetch = function () {
        return originalFetch.apply(this, arguments).then(function (data) {
            checkIfRefreshToken();
            return data;
        });
    };

    function checkIfRefreshToken() {
        if (!window.localStorage.getItem('refresh_token'))
            window.location.href = frontend_host + 'Login/login.html';
    }
})();

function exchangeRefreshForAccess() {
    console.log('exchanging');
    const refresh_token = window.localStorage.getItem('refresh_token');
    console.log('stored refresh' + refresh_token);

    if (!refresh_token)
        window.location.href = frontend_host + 'Login/login.html';

    return fetch(backend_host + 'api/token/refresh/', {
        method: 'POST',
        headers: {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({refresh: refresh_token})
    }).then(res => res.json()).then(res => {
        if(res >= 400 && res <= 499)
            window.location.href = frontend_host + 'Login/login.html';
        else
             localStorage.setItem('access_token', res.access)
    }).catch(function (error) {
        // failed to refresh token?
      //  window.location = host + '/login';
    });
}

function apiFetch(url, method, data) {
    header = {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + localStorage.getItem("access_token")
        }

    request_info = {
        method: method,
        headers: header,
    }


    if(method.toLowerCase() === "post")
        request_info.body = JSON.stringify(data);

    return fetch(backend_host + url, request_info).then(res => {
        if(res.status == 401) {
            console.log("Need to renew access");
            exchangeRefreshForAccess().then(res => {
                console.log("calling it again!");
            }).then(resp =>
            {
                return apiFetch(url, method, data)
            })
        } else {
            console.log("returning this json");
            return res.json()
        }
    }).catch(function (error) {
        console.log(error);
    })
}
