var dev = true;

if(dev) {
    frontend_host = "http://localhost:63342/"
    backend_host = "http://localhost:8000/"
} else {
    backend_host = "https://revdev.studio/"
    frontend_host = "https://revdev.studio/"
}