function openNav() {
    document.getElementById("mySidebar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}

// this will populate the header with the right stuff from backend
getUserMe().then(res => {
    const avatar_url = res.avatar_url
    const first_name = res.user.first_name
    const last_name = res.user.last_name
    $("#avatar").attr('src', avatar_url)
    $("#revdev_name").text(`${first_name + ' ' + last_name}`)
})