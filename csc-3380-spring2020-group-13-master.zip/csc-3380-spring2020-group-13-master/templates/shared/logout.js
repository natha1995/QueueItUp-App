var appiD = '211189340132904';



window.fbAsyncInit = function () {
    FB.init({
        appId: appiD,
        cookie: true,                     // Enable cookies to allow the server to access the session.
        xfbml: true,                     // Parse social plugins on this webpage.
        version: 'v6.0'           // Use this Graph API version for this call.
    });
};

(function (d, s, id) {                      // Load the SDK asynchronously
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s);
    js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));

function deleteCookie(name) {
    document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function logout() {
    console.log("click logout");
    FB.getLoginStatus(function (response) {
        if (response && response.status === 'connected') {
            console.log('connected');
            FB.logout(function (response) {
                console.log(response);
                console.log('loggedo ut');
                window.localStorage.clear();
                // delete facebook cookie, chrome bug!
                deleteCookie("fblo_" + appiD); // fblo_yourFBAppId. example: fblo_444499089231295
                window.location.href = frontend_host + 'Login/login.html';
            });
        }
    });
}