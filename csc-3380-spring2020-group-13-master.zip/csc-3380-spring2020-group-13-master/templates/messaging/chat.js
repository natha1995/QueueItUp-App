function getSocketPath() {
    var ws_scheme = window.location.protocol == "https:" ? "wss" : "ws";
    var token = localStorage.getItem("access_token");
    var ws_path = ws_scheme + '://' + backend_host.split("//")[1] + "chat/stream/?token=" + token;
    return ws_path;
}

var ws = null;

function startWebSocket() {
    console.log("Start");
    try {
        ws = new WebSocket(getSocketPath());
    } catch(e) {
        ws = null;
        console.log("restarting");
        startWebSocket(getSocketPath());
    }
    ws.onmessage = function (evt) {
        alert('message received');
    };
    ws.onclose = function () {
        ws = null;
        console.log('closed')
        // Try to reconnect in 5 seconds
        setTimeout(function () {
            startWebSocket(getSocketPath())
        }, 4000);
    };
    ws.onmessage = function (message) {
        var data = JSON.parse(message.data);
        if (data.msg_type == 0) {
            addMessageToChat(data.message, data.avatar)
        }
    }

    ws.onerror = function (message) {
        console.log('error')
        // exchangeRefreshForAccess().then(res => {
        //
        //
        // })
    }

}

startWebSocket(getSocketPath())

function joinGroup(socket, group_id) {
    socket.send(JSON.stringify({
        "command": "join",
        "group": group_id,
    }));
}


function leaveGroup(socket, group_id) {
    socket.send(JSON.stringify({
        "command": "leave",
        "group": parseInt(group_id),
    }));
}