const groupListTemplate = Handlebars.compile('<li id="{{group_id}}" group_name="{{group_name}}" group_initials="{{group_initials}}" class="{{active}} grouplist">\n' +
    '                            <div class="d-flex bd-highlight">\n' +
    '                               <div class="img_cont">\n' +
    '                                     <div id="group_avatar_list">{{group_initials}}</div>' +
    '                                </div>\n' +
    '                                <div class="user_info">\n' +
    '                                    <span>{{ group_name }}</span>\n' +
    '                                </div>\n' +
    '                            </div>\n' +
    '                        </li>');

const messages = $('#messages');

function populateGroupList(data) {
    for (var group of data) {

        var group_initials = "";
        for (var word of group.group_name.split(" ")) {
            group_initials += word.charAt(0);
        }
        $('#groups').append(groupListTemplate({
            group_id: group.id,
            group_name: group.group_name,
            group_initials: group_initials
        }));
    }
}

apiFetch("api/group/", 'GET', null).then(res => {
    populateGroupList(res);
});


function emptyChatMessages() {
    messages.empty();
}

function setNewNameForChatMessage(current_group_element) {
    let group_name = $(current_group_element).attr('group_name');
    let group_initials = $(current_group_element).attr('group_initials');
    $("#chat_name").text(group_name);
    $('#group_avatar_main').text(group_initials);
}

function leaveOldChat() {
    var selectedChat = $('li.active');
    if (selectedChat != null && selectedChat.length > 0) {
        leaveGroup(ws, selectedChat.attr('id'));
        selectedChat.attr('class', '');
    }
}

var message_template = Handlebars.compile('<div class="d-flex justify-content-end mb-4">\n' +
    '                        <div class="msg_cotainer_send">\n' +
    '                            {{message}}\n' +
    '                        </div>\n' +
    '                        <div class="img_cont_msg">\n' +
    '                            <img src= "{{avatar}}"class="rounded-circle user_img_msg">\n' +
    '                        </div>\n' +
    '                    </div>');

function scrollToBottom() {
    messages[0].scrollTop = messages[0].scrollHeight;
}

function addMessageToChat(message, avatar_url) {
    messages.append(message_template({message: message, avatar: avatar_url}))
    shouldScroll = messages[0].scrollTop + messages[0].clientHeight === messages[0].scrollHeight;
    if (!shouldScroll) {
        scrollToBottom();
    }
}

function joinNewChat(current_group_element) {


    const group_element = $(current_group_element)
    const group_id = group_element.attr('id')

    // this part will make the group list look selected.
    group_element.attr('class', 'active')

    // this part will fetch from the backend and populate the group messages (history)
    apiFetch(`api/messages/${group_id}/`, "GET", {
        "body": "tits",
        "group": 2
    }).then(messages => {
        for (message of messages) {
            const avatar = message.sender.avatar_url
            const body = message.body
            addMessageToChat(body, avatar)
        }
    })

    joinGroup(ws, group_id)

}

// handle changs wheenver user clicks group
$('body').on('click', '#groups > li', function (e) {
    emptyChatMessages();
    leaveOldChat();
    setNewNameForChatMessage(e.currentTarget)
    joinNewChat(e.currentTarget);
});

$('#message_text_box').on('keypress', function (e) {

    if (e.which == 13) { // this is "enter key"
        var selectedChat = $('li.active');
        if (selectedChat != null && selectedChat.length > 0) {
            e.preventDefault();
            const group_id = selectedChat.attr('id');
            const body = $(this).val();
            apiFetch("api/messages/", "POST", {
                "body": body,
                "group": group_id
            }).then(res => $(this).val(''))

        }
    }
});