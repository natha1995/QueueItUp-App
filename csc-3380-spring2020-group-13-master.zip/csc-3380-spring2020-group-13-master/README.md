# Rev Dev (In PROGRESS)

Rev Dev is a social platform where users can discover new musics. They can accomplish this by sharing music with their others and listening to the same playlist and queues.

## Prerequisites before running our project

- Python 3.4+
- Git

## Building our project
Clone the project with:
```git
git clone https://github.com/clintonjwalker/csc-3380-spring2020-group-13.git
```

Now we need to install the python packages (Django and other libraries) to run our project. 

First change to the directory where your project was installed with:
```bash
cd projectdirectory
```
then type
```pip
pip install -r requirements.txt 
```

## Familiarizing ourselves with Git.
### Creating a new branch
<sub><b> You should create a new branch whenever working on a new feature. </b></sub>

To create a new branch of master, ensure you are on the master branch with:
```git
git checkout master
```
then 
```git
git checkout -b "Name of your new branch"
```
This will create a new branch on your <b>Local repository</b>

---
### Staging our changes
<sub><b> Staging your files will tell Git what files to look at whenever saving your code changes. </b></sub>

Once you are done modifying your code, you have to stage your code changes by typing
```git
git add .
```
The "." means add ALL modified files to your upcoming commit.

---

### Commiting a change
<sub><b> A code commit is used to save changes in your local repository </b></sub>

To commit a code change, type
```git
git commit -m "Your message descripting your git changes"
```
---

### Pushing our changes.
<sub><b> Pushing your code changes will allow your other team members to see what you've worked on. </b></sub>

Finally to push these changes to your remote server branch (Github), type
```git
git push
```
---

### Pulling other changes.
<sub><b> Pulling changes will allow you to see what other team members have worked on since your last pull</b></sub>

Ensure to pull often, because other team members may have pushed code to a branch that you are currently working on. You will not get their changes unless you pull!
```git
git pull
```

## Usage
To run the webserver so that you can access the webpages, type:
```bash
python manage.py runserver
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
