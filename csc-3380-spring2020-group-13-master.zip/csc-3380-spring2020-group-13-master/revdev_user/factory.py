from django.contrib.auth.models import User
from social_django.utils import load_strategy, load_backend

from revdev_user.serializers import SocialLoginSerializer
from revdev_user.utils import get_account_adapter


class AccountFactory:
    abstract_user = None

    def create(self): # factory method
        pass

    def get_adapted_account(self): # returns the adapted user.
        return get_account_adapter(self.abstract_user)


class FacebookAccountFactory(AccountFactory):

    def create(self, info):
        # load straetgy and #loadbackend is an external framework that handles the creation of a FaceBook account.
        strategy = load_strategy(info)
        backend = load_backend(strategy=strategy, name='facebook', redirect_uri=None)
        serializer = SocialLoginSerializer(data=info.data, context={"request": info, "backend": backend})
        if serializer.is_valid():
            facebook_user = serializer.validated_data['user']
            self.abstract_user = facebook_user
            return self.abstract_user
        return None


class NormalAccountFactory(AccountFactory):

    def create(self, info):
        user = User.objects.create(
            username=info['username'],
            email=info['email'],
            first_name=info['first_name'],
            last_name=info['last_name']
        )
        user.set_password(info['password'])
        self.abstract_user = user
        return self.user


##  creates a factory based off the string
def get_account_factory(acc_type):
    factory = None
    if acc_type == 'normal':
        factory = NormalAccountFactory()
    elif acc_type == 'facebook':
        factory = FacebookAccountFactory()
    return factory