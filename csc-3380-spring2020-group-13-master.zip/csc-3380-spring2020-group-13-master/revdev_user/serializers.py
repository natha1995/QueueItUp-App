from urllib.error import HTTPError

from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
from rest_framework import serializers

from revdev_user.models import Profile
from revdev_user.utils import get_account_adapter

UserModel = get_user_model()


class SocialLoginSerializer(serializers.Serializer):
    access_token = serializers.CharField(required=True)

    def validate(self, attrs):
        backend = self.context['backend'];
        try:
            user = backend.do_auth(attrs['access_token']);
            if not user:
                raise serializers.ValidationError("Invalid access token")
        except HTTPError:
            raise serializers.ValidationError('Invalid access_token')
        attrs['user'] = user
        return attrs


class RegisterNormalUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'password', 'email', 'first_name', 'last_name')
        write_only_fields = ('password',)
        read_only_fields = ('id',)



class DjangoUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserModel
        fields = ['id', 'username', 'first_name', 'last_name']


class RevDevUserSerializer(serializers.ModelSerializer):
    user = DjangoUserSerializer(read_only=True)
    avatar_url = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Profile
        fields = ['id', 'bio', 'language', 'user', 'avatar_url']
        read_only_fields = ['id',]

    def get_avatar_url(self, profile):
        return get_account_adapter(profile.user).get_avatar_path()

