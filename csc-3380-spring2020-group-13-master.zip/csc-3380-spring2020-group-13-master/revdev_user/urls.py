from django.urls import path

from . import views

urlpatterns = [
    path('', views.PlainFacebookTest.as_view(), name='index'),
]