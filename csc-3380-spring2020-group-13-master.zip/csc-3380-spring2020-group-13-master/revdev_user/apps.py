from django.apps import AppConfig


class RevDevUser(AppConfig):
    name = 'revdev_user'
