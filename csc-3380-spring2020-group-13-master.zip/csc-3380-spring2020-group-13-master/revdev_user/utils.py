import importlib


def get_account_adapter(request):
    return getattr(importlib.import_module('revdev_user.adapters'), 'RevDevUserAdapter')(request)