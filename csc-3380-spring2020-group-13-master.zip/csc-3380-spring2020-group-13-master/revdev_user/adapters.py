from django.contrib.auth.models import User

from revdev_user.utils import get_account_adapter


class RevDevUserAdapter(object):

    def __init__(self, user=None):
        self.django_user = user;


    def get_profile(self):
        return self.django_user.profile

    def get_friends(self):
        # facebook_account = self.get_social_account()
        # if not facebook_account:
        #     return []
        #
        # # We should cache this later on, so that we do not spam facebook's api.
        # url = 'https://graph.facebook.com/{0}/friends?access_token={1}'.format(facebook_account.uid,
        #                                                                        facebook_account.extra_data["access_token"])
        # response = requests.get(url)
        # if response.status_code != 200:
        #     return []
        #
        # friend_return = []
        # json_results = response.json()
        #
        # for friend in json_results['data']:
        #     # checks in our database if the user is in our internal database.
        #     registered_account = UserSocialAuth.objects.filter(uid=friend["id"]).first()
        #     if registered_account:
        #         friend_return.append(get_account_adapter(registered_account.user))

        # NOTE: The above code works for production Facebook Applications, however due to COVID 19, they are not allowing
        # individuals to make production apps. Their verification system is currently down, so we will make all registered
        # users friends for now.
        return [get_account_adapter(user) for user in User.objects.all()]

    def is_social_account(self):
        return self.django_user.social_auth.filter(provider='facebook').first() is not None

    def get_avatar_path(self):
        facebook_account = self.django_user.social_auth.filter(provider='facebook').first()
        if facebook_account:
            return 'https://graph.facebook.com/{0}/picture?type=large'.format(facebook_account.uid)
        return None