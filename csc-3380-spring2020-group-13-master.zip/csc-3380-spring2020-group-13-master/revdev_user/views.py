from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render
from django.views.generic import TemplateView

from rest_framework import permissions, status
from rest_framework.response import Response
from rest_framework.status import HTTP_400_BAD_REQUEST
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from social_django.utils import load_strategy, load_backend

from revdev_user.factory import get_account_factory
from revdev_user.utils import get_account_adapter
from revdev_user.serializers import SocialLoginSerializer, RevDevUserSerializer, RegisterNormalUserSerializer


class LoginPage(TemplateView):
    template_name = "login/login.html"

class PlainFacebookTest(TemplateView):
    template_name = "plainfacebook.html"


class UserProfileView(APIView):
    serializer_class = RevDevUserSerializer

    def get(self, request, pk=None):
        if pk is not None:
            try:
                django_user = User.objects.get(id=pk)
                revdev_user = get_account_adapter(django_user)
                profile = revdev_user.get_profile()
            except User.DoesNotExist as e:
                return Response(status=status.HTTP_400_BAD_REQUEST)
        else:
            profile = get_account_adapter(request.user).get_profile()
        serializer = self.serializer_class(profile, many=False)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request, pk=None):
        serializer = self.serializer_class(request.user.profile, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserFriends(APIView):
    serializer_class = RevDevUserSerializer

    def get(self, request):
        user = get_account_adapter(request.user)
        friends = user.get_friends()
        friends_profiles = [friend.get_profile() for friend in friends if friend.django_user.id != request.user.id]
        serializer = self.serializer_class(friends_profiles, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class NormalUserRegister(APIView):
    serializer_class = RegisterNormalUserSerializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            factory = get_account_factory('normal')
            factory.create(request)  # request contains information to create acc
            user = factory.get_adapted_account()  # grabs the user state of the factory to adapt it into our custom user
            token = RefreshToken.for_user(user.django_user)
            return Response({
                "refresh": str(token),
                "access": str(token.access_token)
            }, status=status.HTTP_200_OK)


class ObtainSocialAuthToken(APIView):
    serializer_class = SocialLoginSerializer
    authentication_classes = []
    permission_classes = []

    def post(self, request):
        factory = get_account_factory('facebook')
        factory.create(request) # request contains information to create acc

        user = factory.get_adapted_account() # grabs the user state of the factory to adapt it into our custom user
        if user is not None:
            token = RefreshToken.for_user(user.django_user)

            return Response({
                "refresh": str(token),
                "access": str(token.access_token)
            }, status=status.HTTP_200_OK)

        return Response('Account cannot be authenticated', status=HTTP_400_BAD_REQUEST)