from django.apps import AppConfig


class QueuePlaylistConfig(AppConfig):
    name = 'queue_playlist'
