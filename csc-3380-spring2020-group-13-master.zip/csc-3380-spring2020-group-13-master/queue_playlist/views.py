from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    return render(request, 'index.html', {'test_arg': "Here is a test argument we can pass to the HTML :)"})