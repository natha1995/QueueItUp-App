from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver

from socket_communication.models import Group


class Song(models.Model):
    youtube_link = models.TextField(max_length=150)
    artist_name = models.TextField(max_length=150)
    album_cover = models.TextField(max_length=150)
    name = models.TextField(max_length=150)


class Playlist(models.Model):
    group = models.OneToOneField(Group, on_delete=models.CASCADE, related_name="playlist", default=None)
    songs = models.ManyToManyField(Song, related_name="songs")


@receiver(post_save, sender=Group)
def create_group_playlist(sender, instance, created, **kwargs):
    if created:
        Playlist.objects.create(group=instance)

